﻿document.addEventListener('DOMContentLoaded',()=>{...});
